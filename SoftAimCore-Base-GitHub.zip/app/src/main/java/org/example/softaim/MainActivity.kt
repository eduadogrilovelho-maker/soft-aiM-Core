package org.example.softaim

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 128, 64, 64)
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 22f
        }

        val label = TextView(this).apply {
            text = "Contador: 0"
            textSize = 18f
            setPadding(0, 48, 0, 16)
        }

        val button = Button(this).apply {
            text = "Incrementar"
        }
        button.setOnClickListener {
            count += 1
            label.text = "Contador: $count"
        }

        root.addView(title)
        root.addView(label)
        root.addView(button)
        setContentView(root)
    }
}
